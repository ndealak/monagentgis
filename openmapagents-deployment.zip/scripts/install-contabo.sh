#!/bin/bash

# 🚀 Script d'installation pour Contabo VPS
# Ce script configure automatiquement votre VPS Contabo pour OpenMap Agents

set -e

echo "╔════════════════════════════════════════════════════════════╗"
echo "║  OpenMap Agents - Installation Contabo VPS                 ║"
echo "╚════════════════════════════════════════════════════════════╝"

# Couleurs
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'

# Étape 1 : Mise à jour du système
echo -e "${BLUE}📦 [1/8] Mise à jour du système...${NC}"
sudo apt-get update
sudo apt-get upgrade -y

# Étape 2 : Installation de Docker
echo -e "${BLUE}🐳 [2/8] Installation de Docker...${NC}"
sudo apt-get install -y apt-transport-https ca-certificates curl software-properties-common
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -
sudo add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable"
sudo apt-get update
sudo apt-get install -y docker-ce docker-ce-cli containerd.io

# Étape 3 : Installation de Docker Compose
echo -e "${BLUE}🐳 [3/8] Installation de Docker Compose...${NC}"
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Étape 4 : Configuration utilisateur
echo -e "${BLUE}👤 [4/8] Configuration de l'utilisateur pour Docker...${NC}"
sudo usermod -aG docker $USER
newgrp docker

# Étape 5 : Installation de Nginx
echo -e "${BLUE}🌐 [5/8] Installation de Nginx...${NC}"
sudo apt-get install -y nginx

# Étape 6 : Installation de Certbot (Let's Encrypt)
echo -e "${BLUE}🔒 [6/8] Installation de Certbot pour SSL...${NC}"
sudo apt-get install -y certbot python3-certbot-nginx

# Étape 7 : Installation de Git
echo -e "${BLUE}📚 [7/8] Installation de Git...${NC}"
sudo apt-get install -y git

# Étape 8 : Création du répertoire d'application
echo -e "${BLUE}📁 [8/8] Création du répertoire d'application...${NC}"
mkdir -p ~/openmapagents
cd ~/openmapagents

echo ""
echo -e "${GREEN}✓ Installation terminée !${NC}"
echo ""
echo "╔════════════════════════════════════════════════════════════╗"
echo "║  Prochaines étapes :                                       ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""
echo "1️⃣  Cloner le projet :"
echo "   cd ~/openmapagents"
echo "   git clone https://github.com/diouck/openmapagents.git ."
echo ""
echo "2️⃣  Configurer OpenAI :"
echo "   cp .env.example .env"
echo "   nano .env"
echo "   # Remplacer OPENAI_API_KEY=sk-..."
echo ""
echo "3️⃣  Lancer l'application :"
echo "   docker-compose build"
echo "   docker-compose up -d"
echo ""
echo "4️⃣  Configurer Nginx + SSL (voir contabo-deploy.sh) :"
echo "   ./setup-nginx.sh votre-domaine.com"
echo ""
echo -e "${GREEN}Votre application démarrera automatiquement au reboot !${NC}"
