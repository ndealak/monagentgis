# 🚀 Scripts de déploiement pour Contabo

Ce dossier contient les scripts d'installation automatisée pour Contabo VPS.

## 📋 Vue d'ensemble

| Script | Rôle | Usage |
|--------|------|-------|
| `install-contabo.sh` | Installation complète du système | `./install-contabo.sh` |
| `setup-nginx.sh` | Configuration Nginx + SSL | `./setup-nginx.sh votre-domaine.com` |
| `setup-systemd.sh` | Auto-démarrage au reboot | `./setup-systemd.sh` |
| `check-contabo.sh` | Vérification du système | `./check-contabo.sh` |

---

## 🚀 Démarrage rapide

### Étape 1 : Se connecter à Contabo
```bash
ssh root@votre-ip-contabo
```

### Étape 2 : Cloner et installer
```bash
git clone https://github.com/diouck/openmapagents.git
cd openmapagents

# Rendre les scripts exécutables
chmod +x scripts/*.sh

# Lancer l'installation
./scripts/install-contabo.sh
```

### Étape 3 : Configuration OpenAI
```bash
cd ~/openmapagents
cp .env.example .env
nano .env
# Remplacer OPENAI_API_KEY=sk-...
```

### Étape 4 : Démarrer l'app
```bash
docker-compose build
docker-compose up -d

# Vérifier
./scripts/check-contabo.sh
```

### Étape 5 : (Optionnel) Configurer HTTPS
```bash
./scripts/setup-nginx.sh votre-domaine.com
```

---

## 📖 Description détaillée

### 1. `install-contabo.sh`

**Qu'est-ce qu'il fait :**
- ✅ Met à jour le système Ubuntu
- ✅ Installe Docker et Docker Compose
- ✅ Installe Nginx
- ✅ Installe Certbot (SSL Let's Encrypt)
- ✅ Installe Git
- ✅ Crée le répertoire `/root/openmapagents`

**Temps d'exécution :** 5-10 minutes

**Exemple :**
```bash
./scripts/install-contabo.sh
```

### 2. `setup-nginx.sh`

**Qu'est-ce qu'il fait :**
- ✅ Crée une configuration Nginx pour proxy HTTP/HTTPS
- ✅ Obtient un certificat SSL gratuit de Let's Encrypt
- ✅ Configure la redirection HTTP → HTTPS
- ✅ Optimise Nginx pour la performance

**Prérequis :**
- Votre domaine doit pointer vers votre IP Contabo
- Ports 80 et 443 doivent être ouverts

**Exemple :**
```bash
./scripts/setup-nginx.sh maps.example.com
```

Après exécution, votre app sera accessible à :
```
https://maps.example.com
```

### 3. `setup-systemd.sh`

**Qu'est-ce qu'il fait :**
- ✅ Crée un service systemd pour l'app
- ✅ Relance automatiquement l'app en cas de problème
- ✅ Démarre automatiquement avecle serveur

**Exemple :**
```bash
./scripts/setup-systemd.sh
```

Vérifier :
```bash
sudo systemctl status openmapagents
```

### 4. `check-contabo.sh`

**Qu'est-ce qu'il fait :**
- 🔍 Vérifie que tous les services sont installés
- 🔍 Teste la connexion Docker
- 🔍 Affiche les ressources (RAM, CPU, disque)
- 🔍 Contrôle l'état de l'application
- 🔍 Suggère des actions si problème

**Exemple :**
```bash
./scripts/check-contabo.sh
```

Output :
```
✅ Docker installé
✅ Docker Compose installé
✅ Nginx installé
✅ Démon Docker actif
ℹ️  RAM disponible: 8Gi
ℹ️  CPU cores: 4
```

---

## 🔄 Workflow complet

```
1. install-contabo.sh
   ↓
2. Configurer .env
   ↓
3. docker-compose build
   ↓
4. docker-compose up -d
   ↓
5. check-contabo.sh (vérifier)
   ↓
6. setup-nginx.sh (optionnel, si vous avez un domaine)
   ↓
7. setup-systemd.sh (optionnel, pour auto-démarrage)
   ✅ Application en production !
```

---

## 🆘 Troubleshooting

### Les scripts ne s'exécutent pas ?

```bash
chmod +x scripts/*.sh
```

### Permission denied ?

```bash
# Si vous n'êtes pas root
sudo ./scripts/install-contabo.sh
```

### Script échoue à l'installation ?

```bash
# Voir les erreurs
sudo apt update
sudo apt upgrade -y
# Puis relancer
./scripts/install-contabo.sh
```

---

## 📚 Plus d'informations

- Documentation complète : [CONTABO-DEPLOY.md](../CONTABO-DEPLOY.md)
- Guide général : [DEPLOY.md](../DEPLOY.md)
- Configuration Docker : [docker-compose.yml](../docker-compose.yml)

---

## 🤝 Besoin d'aide ?

1. Vérifier les logs : `docker-compose logs -f`
2. Consulter le guide : `cat CONTABO-DEPLOY.md`
3. Créer une issue : https://github.com/diouck/openmapagents/issues
