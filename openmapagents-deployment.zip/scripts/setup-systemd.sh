#!/bin/bash

# Création de systemd service pour auto-démarrage
# Ce fichier est appelé par install-contabo.sh

echo "⚙️  Configuration du service systemd..."

sudo tee /etc/systemd/system/openmapagents.service > /dev/null <<EOF
[Unit]
Description=OpenMap Agents Application
After=docker.service network-online.target
Wants=network-online.target

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=%h/openmapagents
ExecStart=/usr/local/bin/docker-compose up -d
ExecStop=/usr/local/bin/docker-compose down
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable openmapagents

echo "✓ Service systemd configuré"
echo ""
echo "L'application démarrera automatiquement à chaque reboot !"
echo ""
echo "Commandes utiles :"
echo "  sudo systemctl status openmapagents   # Voir le statut"
echo "  sudo systemctl restart openmapagents  # Redémarrer"
echo "  sudo systemctl logs openmapagents -f  # Voir les logs"
