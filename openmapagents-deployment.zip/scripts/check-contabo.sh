#!/bin/bash

# Script de vérification pour Contabo
# Vérifie que tout est correctement installé

echo "╔════════════════════════════════════════════════════════════╗"
echo "║  Vérification Contabo VPS - OpenMap Agents                 ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""

PASS=0
FAIL=0

check() {
    if eval "$1" > /dev/null 2>&1; then
        echo "✅ $2"
        ((PASS++))
    else
        echo "❌ $2"
        ((FAIL++))
    fi
}

warning() {
    echo "⚠️  $1"
}

info() {
    echo "ℹ️  $1"
}

# Vérifications système
echo "🔍 Vérifications système..."
check "command -v docker" "Docker installé"
check "command -v docker-compose" "Docker Compose installé"
check "command -v nginx" "Nginx installé"
check "command -v certbot" "Certbot installé"
check "command -v git" "Git installé"

echo ""
echo "🐳 Vérifications Docker..."
check "docker ps" "Démon Docker actif"
check "[ -d ~/openmapagents ]" "Répertoire ~/openmapagents existe"

if [ -d ~/openmapagents ]; then
    cd ~/openmapagents
    
    check "[ -f docker-compose.yml ]" "docker-compose.yml existe"
    check "[ -f .env ]" "Fichier .env existe"
    
    if [ -f .env ]; then
        if grep -q "OPENAI_API_KEY=sk-" .env; then
            check "true" "Clé OpenAI configurée"
        else
            warning "Clé OpenAI non configurée (démarrage échouera)"
            ((FAIL++))
        fi
    fi
fi

echo ""
echo "💾 Vérifications ressources..."

# RAM
RAM=$(free -h | awk '/^Mem:/ {print $2}')
info "RAM disponible: $RAM"

# CPU
CPUS=$(nproc)
info "CPU cores: $CPUS"

# Espace disque
DISK=$(df -h / | awk 'NR==2 {print $4 " libre / " $2 " total"}')
info "Disque: $DISK"

echo ""
echo "🌐 Vérifications réseau..."
check "curl -s http://localhost:8000 > /dev/null 2>&1 || true" "Port 8000 accessible (optionnel si app pas lancée)"

IP=$(hostname -I | awk '{print $1}')
info "IP du serveur: $IP"

if command -v nginx &> /dev/null; then
    if sudo systemctl is-active --quiet nginx 2>/dev/null; then
        check "true" "Nginx actif"
    else
        warning "Nginx installé mais non actif (lancez: sudo systemctl start nginx)"
        ((FAIL++))
    fi
fi

echo ""
echo "📊 État de l'application..."

if [ -d ~/openmapagents ]; then
    cd ~/openmapagents
    
    if docker-compose ps 2>/dev/null | grep -q "openmapagents"; then
        check "true" "Conteneur Docker actif"
        
        if docker-compose logs 2>/dev/null | grep -q "Application startup complete"; then
            check "true" "Application démarrée avec succès"
        else
            warning "Application en cours d'initialisation ou erreur"
        fi
    else
        info "Conteneur Docker non lancé (utilisez: docker-compose up -d)"
    fi
fi

echo ""
echo "╔════════════════════════════════════════════════════════════╗"
echo "║  Résultat : $PASS ✅ / $FAIL ❌                              "
echo "╚════════════════════════════════════════════════════════════╝"
echo ""

if [ $FAIL -eq 0 ]; then
    echo "🎉 Tout est prêt !"
    echo ""
    echo "Accéder à l'app :"
    echo "  • http://$IP:8000              (HTTP)"
    echo "  • https://votre-domaine.com    (HTTPS, si configuré)"
else
    echo "⚠️  $FAIL point(s) à corriger"
    echo ""
    echo "Voir CONTABO-DEPLOY.md pour plus d'aide"
fi

echo ""
echo "Commandes utiles :"
echo "  docker-compose logs -f          : Voir les logs en direct"
echo "  docker-compose restart          : Redémarrer l'app"
echo "  docker-compose down             : Arrêter l'app"
echo "  sudo systemctl status nginx      : État de Nginx"
