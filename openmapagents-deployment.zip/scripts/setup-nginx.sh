#!/bin/bash

# Configuration Nginx + SSL Let's Encrypt pour Contabo
# Usage: ./setup-nginx.sh votre-domaine.com

DOMAIN="${1:-openmapagents.local}"

if [ -z "$1" ]; then
    echo "Usage: $0 votre-domaine.com"
    echo "Exemple: $0 maps.example.com"
    exit 1
fi

echo "╔════════════════════════════════════════════════════════════╗"
echo "║  Configuration Nginx + SSL pour $DOMAIN"
echo "╚════════════════════════════════════════════════════════════╝"

# Créer la configuration Nginx
echo "📝 Création de la configuration Nginx..."

sudo tee /etc/nginx/sites-available/openmapagents > /dev/null <<EOF
# Redirection HTTP → HTTPS
server {
    listen 80;
    listen [::]:80;
    server_name $DOMAIN;

    location /.well-known/acme-challenge/ {
        root /var/www/certbot;
    }

    location / {
        return 301 https://\$server_name\$request_uri;
    }
}

# Configuration HTTPS
server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name $DOMAIN;

    # Certificats SSL (seront créés par Certbot)
    ssl_certificate /etc/letsencrypt/live/$DOMAIN/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/$DOMAIN/privkey.pem;

    # Configuration SSL optimisée
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;

    # Gzip compression
    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss;
    gzip_min_length 256;

    # Logs
    access_log /var/log/nginx/openmapagents-access.log;
    error_log /var/log/nginx/openmapagents-error.log;

    # Proxy vers l'application Docker
    location / {
        proxy_pass http://localhost:8000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }

    # API avec cache disabled
    location /api/ {
        proxy_pass http://localhost:8000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_pragma \$http_authorization;
        add_header Cache-Control "no-store, no-cache, must-revalidate, proxy-revalidate";
    }
}
EOF

# Activer la configuration
echo "🔗 Activation de la configuration Nginx..."
sudo ln -sf /etc/nginx/sites-available/openmapagents /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default

# Test de la configuration
echo "🧪 Vérification de la configuration Nginx..."
sudo nginx -t

# Redémarrer Nginx
echo "🔄 Redémarrage de Nginx..."
sudo systemctl restart nginx

# Obtenir le certificat SSL
echo ""
echo "🔐 Création du certificat SSL avec Let's Encrypt..."
echo "   (Assurez-vous que $DOMAIN pointe vers votre serveur Contabo)"
echo ""

sudo certbot certonly --nginx -d "$DOMAIN" --non-interactive --agree-tos --email admin@"$DOMAIN" --no-eff-email

if [ $? -eq 0 ]; then
    echo ""
    echo "╔════════════════════════════════════════════════════════════╗"
    echo "║  ✓ Configuration Nginx + SSL terminée !                    ║"
    echo "╚════════════════════════════════════════════════════════════╝"
    echo ""
    echo "✅ Votre application est accessible à :"
    echo "   https://$DOMAIN"
    echo ""
    echo "📊 Documentation API :"
    echo "   https://$DOMAIN/docs"
    echo ""
    echo "Renouvellement automatique du certificat SSL en background"
else
    echo ""
    echo "❌ Erreur lors de la création du certificat SSL"
    echo ""
    echo "Vérifications :"
    echo "1. $DOMAIN pointe-t-il vers $(hostname -I) ?"
    echo "2. Port 80 et 443 sont-ils ouverts ?"
    echo "3. Nginx est-il bien redémarré ?"
fi
